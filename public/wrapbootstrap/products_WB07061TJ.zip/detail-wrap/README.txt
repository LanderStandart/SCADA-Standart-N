Detail Admin Bootstrap Theme

Credits:

- Open sans webfont http://www.google.com/fonts/specimen/Open+Sans
- Icons by Brankic1979 http://www.brankic1979.com/icons/
- Blurred bgs from http://clikfocus.com/blog/26-free-high-resolution-blurred-backgrounds-psd

*** 
Documentation on doc.txt


*** 
Changelog

v1.0
Initial release

v1.2
- Added a dark skin on css/skins folder
- Added custom dropdown menus on navbar for messages and notifications, styles are located on layout.css
- Added wizard form page using fuelux js plugin (http://exacttarget.github.io/fuelux/#wizard), styles are located on form-wizard.css
- Added code editor page using Ace Editor (http://ace.ajax.org/)
_ Added grids page to showcase how grids can be used in theme, styles located on grids.css
- Added submenus on sidebar navigation menu, styles are located on layout.css
- Changed how the navigation menu is shown on tablet and mobile devices, now sliding from the left side like facebook-app-style

v2.0
- Added a Bootstrap 3 theme version while also maintaining support for v3.2
- Added DataTables plugin for both versions