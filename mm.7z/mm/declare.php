<?php
$GLOBALS["DB_DATABASENAME"]="localhost:E:\\base\\ZTRADE.FDB";
$GLOBALS["DB_USER"]="SYSDBA";
$GLOBALS["DB_PASSWD"]="masterkey";
?>