﻿<header><nav class="navbar navbar-expand-md bg-dark navbar-dark">
<a class="navbar-brand" href="./index.php"><div class="logo"> </div></a>

<div  style="color:white;font-size: 1rem;max-width: 5rem;align-content: justify">Сводный менеджер </div><div style="width: 5rem"></div>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav1">
    <span class="navbar-toggler-icon"></span>
  </button>
<div id="nav1" class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto">
<li class="nav-item"><a class="nav-link" style="display: inline-block" href="index.php?total"> Сводная информация</a></li>
<li class="nav-item"><a class="nav-link" href="index.php?profile_list">Список профилей</a></li>
<li class="nav-item"><a class="nav-link" href="index.php?warebase">Остатки</a></li>
<li class="nav-item"><a class="nav-link" href="index.php?docs">Журнал документов</a></li>
<li class="nav-item"><a class="nav-link" href="index.php?reports">Отчеты</a></li>
</ul></div>
<div id="nav1" class="collapse navbar-collapse">
	<span style="color:White">:=user_caption=:</span>
<ul class="navbar-nav mr-auto">
<li class="nav-item"><a class="nav-link" href="index.php?logout">Выход</a></li></div>
</nav></ul>
</header>

